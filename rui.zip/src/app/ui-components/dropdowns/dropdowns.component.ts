import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ronx-dropdowns',
  templateUrl: './dropdowns.component.html',
  styleUrls: ['./dropdowns.component.css'],
})
export class DropdownsComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
